# CMPT213-Assignment3
While running the assignment, it expects 1 or 2 arguments
If you pass 1 argument, it should be the number of tanks to be placed on the tank.
It must be an int greater than or equal to 0.

If no argument is passed, default number of tanks will be taken as 5.

Second argument is --cheat. 
It will disclose the gameModel with the tanks contained and hence you can shot on looking at the actual positions of the tanks.

ENJOY THE GAME!

To run the game, you need to go into the directory which contains the src folder of the game, go into that folder and try running the following command on the terminal

java ca.cmpt213.ui.FortressDefence <Optional 1st argument> <Optional 2nd argument>
